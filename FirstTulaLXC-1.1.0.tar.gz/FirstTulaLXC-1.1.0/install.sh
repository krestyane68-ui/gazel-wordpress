#!/bin/sh
set -eu

SERVICE_NAME="first-tula-tv"
INSTALL_DIR="/opt/first-tula-tv"
CONFIG_FILE="/etc/first-tula-tv.conf"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

fail() {
    printf 'ОШИБКА: %s\n' "$1" >&2
    exit 1
}

valid_ipv4() {
    printf '%s\n' "$1" | awk -F. '
        NF != 4 { exit 1 }
        {
            for (i = 1; i <= 4; i++) {
                if ($i !~ /^[0-9]+$/ || $i < 0 || $i > 255) exit 1
            }
        }
    '
}

detect_ipv4() {
    detected=""
    if command -v ip >/dev/null 2>&1; then
        detected=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '
            {
                for (i = 1; i <= NF; i++) {
                    if ($i == "src" && (i + 1) <= NF) {
                        print $(i + 1)
                        exit
                    }
                }
            }
        ')
    fi
    if [ -z "$detected" ]; then
        detected=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    printf '%s' "$detected"
}

[ "$(id -u)" -eq 0 ] || fail "запустите установщик от root: bash install.sh"
[ -d /run/systemd/system ] || fail "контейнер должен использовать systemd"
[ -f "$SCRIPT_DIR/server.py" ] || fail "рядом с install.sh отсутствует server.py"
[ -f "$SCRIPT_DIR/FirstTulaLive.zip" ] || fail "рядом с install.sh отсутствует FirstTulaLive.zip"
[ -f "$SCRIPT_DIR/first-tula-tv.service" ] || fail "рядом с install.sh отсутствует first-tula-tv.service"

SERVER_IP=${FIRST_TULA_IP:-$(detect_ipv4)}
[ -n "$SERVER_IP" ] || fail "IPv4 не найден. Запустите: FIRST_TULA_IP=192.168.1.50 bash install.sh"
valid_ipv4 "$SERVER_IP" || fail "некорректный IPv4: $SERVER_IP"

printf 'Устанавливается сервер для адреса %s...\n' "$SERVER_IP"

if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends python3 ca-certificates iproute2
else
    fail "поддерживаются Debian и Ubuntu с apt-get"
fi

if ! getent passwd firsttula >/dev/null 2>&1; then
    useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin firsttula
fi

install -d -o root -g root -m 0755 "$INSTALL_DIR"
install -o root -g root -m 0755 "$SCRIPT_DIR/server.py" "$INSTALL_DIR/server.py"
install -o root -g root -m 0644 "$SCRIPT_DIR/FirstTulaLive.zip" "$INSTALL_DIR/FirstTulaLive.zip"
install -o root -g root -m 0644 "$SCRIPT_DIR/first-tula-tv.service" "$SERVICE_FILE"

umask 022
{
    printf 'FIRST_TULA_IP=%s\n' "$SERVER_IP"
    printf 'FIRST_TULA_BIND=0.0.0.0\n'
    printf 'FIRST_TULA_PORT=80\n'
} > "$CONFIG_FILE"

systemctl daemon-reload
systemctl enable "$SERVICE_NAME.service" >/dev/null
systemctl restart "$SERVICE_NAME.service"

ready=0
attempt=0
while [ "$attempt" -lt 15 ]; do
    if python3 -c 'import urllib.request; raise SystemExit(0 if urllib.request.urlopen("http://127.0.0.1/health", timeout=2).read().strip() == b"ok" else 1)' 2>/dev/null; then
        ready=1
        break
    fi
    attempt=$((attempt + 1))
    sleep 1
done

if [ "$ready" -ne 1 ]; then
    printf '\nСлужба не запустилась. Последние сообщения:\n' >&2
    journalctl -u "$SERVICE_NAME.service" -n 30 --no-pager >&2 || true
    exit 1
fi

printf '\nУстановка завершена.\n'
printf 'Сервер: http://%s/\n' "$SERVER_IP"
printf 'Проверка: http://%s/health\n' "$SERVER_IP"
printf '\nДля просмотра оставьте LXC включённым.\n'
printf 'Логи: journalctl -u %s -f\n' "$SERVICE_NAME"
printf 'Состояние: systemctl status %s --no-pager\n' "$SERVICE_NAME"
printf '\nЕсли приложение запомнило другой IP, выполните App Sync один раз с адресом %s.\n' "$SERVER_IP"
