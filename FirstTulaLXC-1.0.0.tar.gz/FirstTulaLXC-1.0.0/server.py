#!/usr/bin/env python3
"""Local resolver and widget server for Samsung Legacy/Orsay TVs."""

import gzip
import html
import io
import ipaddress
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


VERSION = "1.0.0"
LIVE_PAGE_URL = "https://1tulatv.ru/live"
FALLBACK_EMBED_URL = "https://ok.ru/videoembed/977507065564?autoplay=1"
PLACEHOLDER = "__FIRST_TULA_RESOLVER_URL__"
USER_AGENT = "Mozilla/5.0 (SMART-TV; Linux; Tizen 2.4.0) AppleWebKit/537.36"

SERVER_IP = ""
WIDGET_BYTES = b""
WIDGET_XML_BYTES = b""
RESOLVE_LOCK = threading.Lock()


def log(message):
    print(message, flush=True)


def get_remote_text(url):
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/vnd.apple.mpegurl,*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
            # Identity avoids incompatible raw-Deflate responses seen in old .NET.
            "Accept-Encoding": "identity",
        },
        method="GET",
    )
    with urllib.request.urlopen(request, timeout=25) as response:
        data = response.read()
        encoding = (response.headers.get("Content-Encoding") or "").lower()
        if encoding == "gzip":
            data = gzip.decompress(data)
        elif encoding == "deflate":
            try:
                data = zlib.decompress(data)
            except zlib.error:
                data = zlib.decompress(data, -zlib.MAX_WBITS)
        charset = response.headers.get_content_charset() or "utf-8"
        return data.decode(charset, errors="replace"), response.geturl()


def to_legacy_url(url):
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme == "https" and (host == "okcdn.ru" or host.endswith(".okcdn.ru")):
        parsed = parsed._replace(scheme="http")
        return urllib.parse.urlunsplit(parsed)
    return url


def select_720p_stream(master_text, master_url):
    if "#EXTM3U" not in master_text:
        return to_legacy_url(master_url)

    lines = master_text.replace("\r", "").split("\n")
    best = None
    fallback = None
    index = 0

    while index < len(lines):
        info = lines[index].strip()
        if not info.startswith("#EXT-X-STREAM-INF:"):
            index += 1
            continue

        index += 1
        uri = ""
        while index < len(lines) and not uri:
            candidate_line = lines[index].strip()
            index += 1
            if candidate_line and not candidate_line.startswith("#"):
                uri = candidate_line
        if not uri:
            continue

        resolution_match = re.search(r"RESOLUTION=\d+x(\d+)", info, re.IGNORECASE)
        bandwidth_match = re.search(r"BANDWIDTH=(\d+)", info, re.IGNORECASE)
        height = int(resolution_match.group(1)) if resolution_match else 0
        bandwidth = int(bandwidth_match.group(1)) if bandwidth_match else 0
        candidate = {
            "url": urllib.parse.urljoin(master_url, uri),
            "height": height,
            "bandwidth": bandwidth,
        }

        if fallback is None or candidate["bandwidth"] < fallback["bandwidth"]:
            fallback = candidate
        if 0 < height <= 720:
            if (
                best is None
                or height > best["height"]
                or (height == best["height"] and bandwidth > best["bandwidth"])
            ):
                best = candidate

    selected = best or fallback
    return to_legacy_url(selected["url"] if selected else master_url)


def normalize_player_html(player_html):
    normalized = html.unescape(player_html)
    normalized = normalized.replace(r'\"', '"')
    normalized = normalized.replace(r"\/", "/")
    normalized = re.sub(r"\\u0026", "&", normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\\u003d", "=", normalized, flags=re.IGNORECASE)
    normalized = re.sub(r"\\u003f", "?", normalized, flags=re.IGNORECASE)
    return normalized


def resolve_first_tula_stream():
    embed_url = FALLBACK_EMBED_URL
    try:
        live_html, _ = get_remote_text(LIVE_PAGE_URL)
        match = re.search(
            r'<iframe[^>]+src=["\']((?:https?:)?//ok\.ru/videoembed/[^"\'<>\s]+)',
            live_html,
            re.IGNORECASE,
        )
        if match:
            embed_url = html.unescape(match.group(1))
            if embed_url.startswith("//"):
                embed_url = "https:" + embed_url
    except Exception as error:
        log("Official page lookup failed; using the known player address: {}".format(error))

    player_html, _ = get_remote_text(embed_url)
    normalized = normalize_player_html(player_html)
    match = re.search(
        r'"hlsMasterPlaylistUrl"\s*:\s*"(https?://[^"<>\s]+)"',
        normalized,
        re.IGNORECASE,
    )
    if not match:
        match = re.search(
            r"(https?://[^\s\"'<>]+\.m3u8(?:\?[^\s\"'<>]*)?)",
            normalized,
            re.IGNORECASE,
        )
    if not match:
        raise RuntimeError("HLS address was not found in the player page")

    master_url = to_legacy_url(match.group(1).strip())
    master_text, effective_master_url = get_remote_text(master_url)
    return select_720p_stream(master_text, to_legacy_url(effective_master_url))


def build_widget(base_widget_path, server_ip):
    output = io.BytesIO()
    replaced = False
    with zipfile.ZipFile(base_widget_path, "r") as source:
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as target:
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename.replace("\\", "/").lower() == "js/stream.js":
                    script = data.decode("utf-8")
                    if PLACEHOLDER not in script:
                        raise RuntimeError("The widget package does not contain the resolver placeholder")
                    script = script.replace(PLACEHOLDER, "http://{}/resolve".format(server_ip))
                    data = script.encode("utf-8")
                    replaced = True
                target.writestr(info, data)
    if not replaced:
        raise RuntimeError("js/stream.js was not found in the widget package")
    return output.getvalue()


class RequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "FirstTulaLXC/{}".format(VERSION)

    def log_message(self, _format, *_args):
        return

    def send_payload(self, status, content_type, payload, include_body=True):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Connection", "close")
        self.end_headers()
        if include_body and payload:
            try:
                self.wfile.write(payload)
            except (BrokenPipeError, ConnectionResetError):
                pass
        self.close_connection = True

    def handle_request(self, include_body):
        path = urllib.parse.urlsplit(self.path).path.lower()
        status = 200
        try:
            if path in ("/", "/widgetlist.xml"):
                self.send_payload(200, "text/xml; charset=utf-8", WIDGET_XML_BYTES, include_body)
            elif path == "/firsttulalive.zip":
                self.send_payload(200, "application/zip", WIDGET_BYTES, include_body)
            elif path == "/health":
                self.send_payload(200, "text/plain; charset=utf-8", b"ok\n", include_body)
            elif path == "/resolve":
                log("Resolving the current broadcast address...")
                with RESOLVE_LOCK:
                    stream_url = resolve_first_tula_stream()
                self.send_payload(
                    200,
                    "text/plain; charset=utf-8",
                    stream_url.encode("utf-8"),
                    include_body,
                )
                log("Broadcast address is ready.")
            else:
                status = 404
                self.send_payload(404, "text/plain; charset=utf-8", b"Not found\n", include_body)
        except Exception as error:
            status = 502
            log("Resolver error: {}".format(error))
            self.send_payload(502, "text/plain; charset=utf-8", b"Resolver error\n", include_body)
        finally:
            client_ip = self.client_address[0] if self.client_address else "-"
            log(
                "{}  {}  {} {}  {}".format(
                    time.strftime("%H:%M:%S"), client_ip, self.command, self.path, status
                )
            )

    def do_GET(self):
        self.handle_request(True)

    def do_HEAD(self):
        self.handle_request(False)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True


def main():
    global SERVER_IP, WIDGET_BYTES, WIDGET_XML_BYTES

    SERVER_IP = os.environ.get("FIRST_TULA_IP", "").strip()
    bind_address = os.environ.get("FIRST_TULA_BIND", "0.0.0.0").strip()
    port_text = os.environ.get("FIRST_TULA_PORT", "80").strip()

    try:
        ipaddress.IPv4Address(SERVER_IP)
    except ipaddress.AddressValueError:
        raise SystemExit("FIRST_TULA_IP must contain the fixed IPv4 address of this LXC")
    try:
        port = int(port_text)
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        raise SystemExit("FIRST_TULA_PORT must be a number from 1 to 65535")

    root = os.path.dirname(os.path.abspath(__file__))
    widget_path = os.path.join(root, "FirstTulaLive.zip")
    if not os.path.isfile(widget_path):
        raise SystemExit("FirstTulaLive.zip was not found next to server.py")

    WIDGET_BYTES = build_widget(widget_path, SERVER_IP)
    widget_xml = """<?xml version="1.0" encoding="UTF-8"?>
<rsp stat="ok">
  <list>
    <widget id="FirstTulaLive" update="y">
      <title>First Tula Live</title>
      <compression type="zip" size="{size}"/>
      <description>First Tula live TV 1.1</description>
      <download>http://{ip}/FirstTulaLive.zip</download>
    </widget>
  </list>
</rsp>
""".format(size=len(WIDGET_BYTES), ip=SERVER_IP)
    WIDGET_XML_BYTES = widget_xml.encode("utf-8")

    server = ThreadingHTTPServer((bind_address, port), RequestHandler)
    log("FIRST TULA TV LXC SERVER {}".format(VERSION))
    log("Server is ready: http://{}:{}/".format(SERVER_IP, port))
    log("Press Ctrl+C to stop the server.")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        log("SERVER ERROR: {}".format(error))
        sys.exit(1)
