$ErrorActionPreference = "Stop"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList $identity
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $PSCommandPath
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $arguments
    exit
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Get-RemoteText([string]$Url) {
    $request = [Net.HttpWebRequest]::Create($Url)
    $request.Method = "GET"
    $request.UserAgent = "Mozilla/5.0 (SMART-TV; Linux; Tizen 2.4.0) AppleWebKit/537.36"
    $request.Accept = "text/html,application/xhtml+xml,application/vnd.apple.mpegurl,*/*"
    $request.Headers.Add("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.7")
    # Some Windows PowerShell/.NET builds cannot decode OK.ru's raw Deflate response.
    # Advertising GZip only avoids "block length does not match its complement".
    $request.AutomaticDecompression = [Net.DecompressionMethods]::GZip
    $request.AllowAutoRedirect = $true
    $request.Timeout = 25000
    $request.ReadWriteTimeout = 25000

    $response = $request.GetResponse()
    try {
        $stream = $response.GetResponseStream()
        $reader = New-Object -TypeName IO.StreamReader -ArgumentList @($stream, [Text.Encoding]::UTF8, $true)
        try {
            return $reader.ReadToEnd()
        } finally {
            $reader.Close()
        }
    } finally {
        $response.Close()
    }
}

function Convert-ToLegacyUrl([string]$Url) {
    if ($Url -match '^https://[^/]+\.okcdn\.ru/') {
        return "http://" + $Url.Substring(8)
    }
    return $Url
}

function Convert-ToAbsoluteUrl([string]$BaseUrl, [string]$Reference) {
    if ($Reference -match '^https?://') {
        return $Reference
    }
    $baseUri = [Uri]$BaseUrl
    if ($Reference.StartsWith("//")) {
        return $baseUri.Scheme + ":" + $Reference
    }
    if ($Reference.StartsWith("/")) {
        return $baseUri.Scheme + "://" + $baseUri.Authority + $Reference
    }
    $slash = $BaseUrl.LastIndexOf("/")
    if ($slash -lt 0) {
        return $Reference
    }
    return $BaseUrl.Substring(0, $slash + 1) + $Reference
}

function Select-720pStream([string]$MasterText, [string]$MasterUrl) {
    if (-not $MasterText.Contains("#EXTM3U")) {
        return (Convert-ToLegacyUrl $MasterUrl)
    }

    $lines = $MasterText.Replace([string][char]13, "").Split([char]10)
    $best = $null
    $fallback = $null

    for ($index = 0; $index -lt $lines.Length; $index++) {
        $info = $lines[$index].Trim()
        if (-not $info.StartsWith("#EXT-X-STREAM-INF:")) {
            continue
        }

        $uri = ""
        while (($index + 1) -lt $lines.Length -and -not $uri) {
            $index++
            $uri = $lines[$index].Trim()
            if ($uri.StartsWith("#")) {
                $uri = ""
            }
        }
        if (-not $uri) {
            continue
        }

        $height = 0
        $bandwidth = 0
        $resolutionMatch = [regex]::Match($info, 'RESOLUTION=\d+x(\d+)', 'IgnoreCase')
        $bandwidthMatch = [regex]::Match($info, 'BANDWIDTH=(\d+)', 'IgnoreCase')
        if ($resolutionMatch.Success) {
            $height = [int]$resolutionMatch.Groups[1].Value
        }
        if ($bandwidthMatch.Success) {
            $bandwidth = [int64]$bandwidthMatch.Groups[1].Value
        }

        $candidate = [PSCustomObject]@{
            Url = Convert-ToAbsoluteUrl $MasterUrl $uri
            Height = $height
            Bandwidth = $bandwidth
        }

        if ($null -eq $fallback -or $candidate.Bandwidth -lt $fallback.Bandwidth) {
            $fallback = $candidate
        }
        if ($candidate.Height -gt 0 -and $candidate.Height -le 720) {
            if ($null -eq $best -or $candidate.Height -gt $best.Height -or
                ($candidate.Height -eq $best.Height -and $candidate.Bandwidth -gt $best.Bandwidth)) {
                $best = $candidate
            }
        }
    }

    if ($null -ne $best) {
        return (Convert-ToLegacyUrl $best.Url)
    }
    if ($null -ne $fallback) {
        return (Convert-ToLegacyUrl $fallback.Url)
    }
    return (Convert-ToLegacyUrl $MasterUrl)
}

function Resolve-FirstTulaStream {
    $liveUrl = "https://1tulatv.ru/live"
    $embedUrl = "https://ok.ru/videoembed/977507065564?autoplay=1"

    try {
        $liveHtml = Get-RemoteText $liveUrl
        $embedMatch = [regex]::Match(
            $liveHtml,
            '<iframe[^>]+src=["'']((?:https?:)?//ok\.ru/videoembed/[^"''<>\s]+)',
            'IgnoreCase'
        )
        if ($embedMatch.Success) {
            $embedUrl = [Net.WebUtility]::HtmlDecode($embedMatch.Groups[1].Value)
            if ($embedUrl.StartsWith("//")) {
                $embedUrl = "https:" + $embedUrl
            }
        }
    } catch {
        Write-Host "Official page lookup failed; using the known player address." -ForegroundColor Yellow
    }

    $playerHtml = Get-RemoteText $embedUrl
    $normalized = [Net.WebUtility]::HtmlDecode($playerHtml)
    $normalized = $normalized.Replace('\"', '"')
    $normalized = $normalized.Replace('\/', '/')
    $normalized = $normalized.Replace('\u0026', '&')
    $normalized = $normalized.Replace('\u003d', '=')
    $normalized = $normalized.Replace('\u003f', '?')

    $hlsMatch = [regex]::Match(
        $normalized,
        '"hlsMasterPlaylistUrl"\s*:\s*"(https?://[^"<>\s]+)"',
        'IgnoreCase'
    )
    if (-not $hlsMatch.Success) {
        $hlsMatch = [regex]::Match(
            $normalized,
            '(https?://[^\s"''<>]+\.m3u8(?:\?[^\s"''<>]*)?)',
            'IgnoreCase'
        )
    }
    if (-not $hlsMatch.Success) {
        throw "HLS address was not found in the player page."
    }

    $masterUrl = $hlsMatch.Groups[1].Value.Trim()
    $masterUrl = Convert-ToLegacyUrl $masterUrl
    $masterText = Get-RemoteText $masterUrl
    return (Select-720pStream $masterText $masterUrl)
}

function New-PatchedWidgetBytes([string]$BaseWidgetPath, [string]$ServerIp) {
    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("FirstTulaWidget-" + [Guid]::NewGuid().ToString("N"))
    $tempZip = Join-Path ([IO.Path]::GetTempPath()) ("FirstTulaWidget-" + [Guid]::NewGuid().ToString("N") + ".zip")
    try {
        [IO.Directory]::CreateDirectory($tempRoot) | Out-Null
        [IO.Compression.ZipFile]::ExtractToDirectory($BaseWidgetPath, $tempRoot)
        $streamScript = Join-Path $tempRoot "js\stream.js"
        $scriptText = [IO.File]::ReadAllText($streamScript, [Text.Encoding]::UTF8)
        if (-not $scriptText.Contains("__FIRST_TULA_RESOLVER_URL__")) {
            throw "The widget package does not contain the resolver placeholder."
        }
        $scriptText = $scriptText.Replace("__FIRST_TULA_RESOLVER_URL__", "http://$ServerIp/resolve")
        $utf8NoBom = New-Object -TypeName Text.UTF8Encoding -ArgumentList $false
        [IO.File]::WriteAllText($streamScript, $scriptText, $utf8NoBom)
        [IO.Compression.ZipFile]::CreateFromDirectory(
            $tempRoot,
            $tempZip,
            [IO.Compression.CompressionLevel]::Optimal,
            $false
        )
        return [IO.File]::ReadAllBytes($tempZip)
    } finally {
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force
        }
        if (Test-Path -LiteralPath $tempZip) {
            Remove-Item -LiteralPath $tempZip -Force
        }
    }
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$widgetPath = Join-Path $root "FirstTulaLive.zip"

if (-not (Test-Path -LiteralPath $widgetPath)) {
    Write-Host "ERROR: FirstTulaLive.zip was not found next to this script." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

$addresses = @()
try {
    $adapters = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
} catch {
    $adapters = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
}
foreach ($adapter in $adapters) {
    foreach ($address in $adapter.IPAddress) {
        if ($address -match '^\d{1,3}(\.\d{1,3}){3}$' -and
            $address -ne '127.0.0.1' -and
            $address -notlike '169.254.*') {
            $addresses += $address
        }
    }
}
$addresses = @($addresses | Sort-Object -Unique)

if ($addresses.Count -eq 0) {
    Write-Host "ERROR: No local IPv4 address was found." -ForegroundColor Red
    Write-Host "Connect the PC and TV to the same router and try again."
    Read-Host "Press Enter to close"
    exit 1
}

if ($addresses.Count -eq 1) {
    $serverIp = $addresses[0]
} else {
    Write-Host "Choose the PC address on the same network as the TV:" -ForegroundColor Cyan
    for ($index = 0; $index -lt $addresses.Count; $index++) {
        Write-Host ("  {0}. {1}" -f ($index + 1), $addresses[$index])
    }
    do {
        $choice = Read-Host "Number"
        $number = 0
        $valid = [int]::TryParse($choice, [ref]$number) -and $number -ge 1 -and $number -le $addresses.Count
    } until ($valid)
    $serverIp = $addresses[$number - 1]
}

Write-Host "Preparing the TV package..."
$zipBytes = New-PatchedWidgetBytes $widgetPath $serverIp
$widgetSize = $zipBytes.Length
$xml = @"
<?xml version="1.0" encoding="UTF-8"?>
<rsp stat="ok">
  <list>
    <widget id="FirstTulaLive" update="y">
      <title>First Tula Live</title>
      <compression type="zip" size="$widgetSize"/>
      <description>First Tula live TV 1.1</description>
      <download>http://$serverIp/FirstTulaLive.zip</download>
    </widget>
  </list>
</rsp>
"@
$xmlBytes = [Text.Encoding]::UTF8.GetBytes($xml)

$firewallRuleName = "FirstTula TV Server"
try {
    & netsh.exe advfirewall firewall delete rule name="$firewallRuleName" | Out-Null
    & netsh.exe advfirewall firewall add rule name="$firewallRuleName" dir=in action=allow protocol=TCP localport=80 remoteip=localsubnet profile=any | Out-Null
} catch {
    Write-Host "Windows Firewall rule could not be updated." -ForegroundColor Yellow
}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://+:80/")

try {
    $listener.Start()
    Clear-Host
    Write-Host "FIRST TULA TV SERVER 1.1.1" -ForegroundColor Green
    Write-Host ""
    Write-Host "Server is ready: http://$serverIp/" -ForegroundColor Yellow
    Write-Host "Keep this window open while installing and watching TV."
    Write-Host "Press Ctrl+C to stop the server."
    Write-Host ""

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $path = $context.Request.Url.AbsolutePath.ToLowerInvariant()
        $response = $context.Response
        $response.Headers.Add("Cache-Control", "no-store, no-cache, must-revalidate")
        $response.Headers.Add("Access-Control-Allow-Origin", "*")

        try {
            if ($context.Request.HttpMethod -eq "OPTIONS") {
                $payload = [byte[]]@()
                $response.StatusCode = 204
                $response.ContentType = "text/plain"
            } elseif ($path -eq "/" -or $path -eq "/widgetlist.xml") {
                $payload = $xmlBytes
                $response.StatusCode = 200
                $response.ContentType = "text/xml; charset=utf-8"
            } elseif ($path -eq "/firsttulalive.zip") {
                $payload = $zipBytes
                $response.StatusCode = 200
                $response.ContentType = "application/zip"
            } elseif ($path -eq "/resolve") {
                Write-Host "Resolving the current broadcast address..." -ForegroundColor Cyan
                $streamUrl = Resolve-FirstTulaStream
                $payload = [Text.Encoding]::UTF8.GetBytes($streamUrl)
                $response.StatusCode = 200
                $response.ContentType = "text/plain; charset=utf-8"
                Write-Host "Broadcast address is ready." -ForegroundColor Green
            } else {
                $payload = [Text.Encoding]::UTF8.GetBytes("Not found")
                $response.StatusCode = 404
                $response.ContentType = "text/plain; charset=utf-8"
            }
        } catch {
            Write-Host ("Resolver error: " + $_.Exception.Message) -ForegroundColor Red
            $payload = [Text.Encoding]::UTF8.GetBytes("Resolver error")
            $response.StatusCode = 502
            $response.ContentType = "text/plain; charset=utf-8"
        }

        $response.ContentLength64 = $payload.Length
        if ($context.Request.HttpMethod -ne "HEAD" -and $payload.Length -gt 0) {
            $response.OutputStream.Write($payload, 0, $payload.Length)
        }
        $response.OutputStream.Close()
        Write-Host ((Get-Date -Format "HH:mm:ss") + "  " + $context.Request.RemoteEndPoint.Address + "  " + $context.Request.HttpMethod + " " + $context.Request.Url.AbsolutePath + "  " + $response.StatusCode)
    }
} catch {
    Write-Host ""
    Write-Host "SERVER ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Port 80 may be occupied, or Windows Firewall may be blocking access."
    Read-Host "Press Enter to close"
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
    $listener.Close()
}
