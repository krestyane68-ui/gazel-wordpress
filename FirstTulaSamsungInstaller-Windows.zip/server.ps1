$ErrorActionPreference = "Stop"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $arguments
    exit
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$widgetPath = Join-Path $root "FirstTulaLive.zip"

if (-not (Test-Path -LiteralPath $widgetPath)) {
    Write-Host "ERROR: FirstTulaLive.zip was not found next to this script." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

$addresses = @()
try {
    $adapters = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
} catch {
    $adapters = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
}

foreach ($adapter in $adapters) {
    foreach ($address in $adapter.IPAddress) {
        if ($address -match '^\d{1,3}(\.\d{1,3}){3}$' -and
            $address -ne '127.0.0.1' -and
            $address -notlike '169.254.*') {
            $addresses += $address
        }
    }
}
$addresses = @($addresses | Sort-Object -Unique)

if ($addresses.Count -eq 0) {
    Write-Host "ERROR: No local IPv4 address was found." -ForegroundColor Red
    Write-Host "Connect the PC and TV to the same router and try again."
    Read-Host "Press Enter to close"
    exit 1
}

if ($addresses.Count -eq 1) {
    $serverIp = $addresses[0]
} else {
    Write-Host "Choose the PC address on the same network as the TV:" -ForegroundColor Cyan
    for ($index = 0; $index -lt $addresses.Count; $index++) {
        Write-Host ("  {0}. {1}" -f ($index + 1), $addresses[$index])
    }
    do {
        $choice = Read-Host "Number"
        $number = 0
        $valid = [int]::TryParse($choice, [ref]$number) -and $number -ge 1 -and $number -le $addresses.Count
    } until ($valid)
    $serverIp = $addresses[$number - 1]
}

$widgetSize = (Get-Item -LiteralPath $widgetPath).Length
$xml = @"
<?xml version="1.0" encoding="UTF-8"?>
<rsp stat="ok">
  <list>
    <widget id="FirstTulaLive">
      <title>First Tula Live</title>
      <compression type="zip" size="$widgetSize"/>
      <description>First Tula live TV</description>
      <download>http://$serverIp/FirstTulaLive.zip</download>
    </widget>
  </list>
</rsp>
"@
$xmlBytes = [Text.Encoding]::UTF8.GetBytes($xml)
$zipBytes = [IO.File]::ReadAllBytes($widgetPath)

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://+:80/")

try {
    $listener.Start()
    Clear-Host
    Write-Host "FIRST TULA TV INSTALL SERVER" -ForegroundColor Green
    Write-Host ""
    Write-Host "Server is ready: http://$serverIp/" -ForegroundColor Yellow
    Write-Host "Keep this window open until App Sync finishes."
    Write-Host "Press Ctrl+C to stop the server."
    Write-Host ""

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $path = $context.Request.Url.AbsolutePath.ToLowerInvariant()
        $response = $context.Response
        $response.Headers.Add("Cache-Control", "no-cache")

        if ($path -eq "/" -or $path -eq "/widgetlist.xml") {
            $payload = $xmlBytes
            $response.StatusCode = 200
            $response.ContentType = "text/xml; charset=utf-8"
        } elseif ($path -eq "/firsttulalive.zip") {
            $payload = $zipBytes
            $response.StatusCode = 200
            $response.ContentType = "application/zip"
        } else {
            $payload = [Text.Encoding]::UTF8.GetBytes("Not found")
            $response.StatusCode = 404
            $response.ContentType = "text/plain; charset=utf-8"
        }

        $response.ContentLength64 = $payload.Length
        if ($context.Request.HttpMethod -ne "HEAD") {
            $response.OutputStream.Write($payload, 0, $payload.Length)
        }
        $response.OutputStream.Close()
        Write-Host ((Get-Date -Format "HH:mm:ss") + "  " + $context.Request.RemoteEndPoint.Address + "  " + $context.Request.HttpMethod + " " + $context.Request.Url.AbsolutePath)
    }
} catch {
    Write-Host ""
    Write-Host "SERVER ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Port 80 may be occupied, or Windows Firewall may be blocking access."
    Read-Host "Press Enter to close"
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
    $listener.Close()
}
