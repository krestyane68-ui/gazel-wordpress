(function (root) {
    "use strict";

    var DISPLAY_WIDTH = 960;
    var DISPLAY_HEIGHT = 540;
    var MEDIA_SOURCE = 43;
    var PLAYER_COMPONENT = "|COMPONENT=HLS";

    var EVENT_CONNECTION_FAILED = 1;
    var EVENT_AUTHENTICATION_FAILED = 2;
    var EVENT_STREAM_NOT_FOUND = 3;
    var EVENT_NETWORK_DISCONNECTED = 4;
    var EVENT_NETWORK_SLOW = 5;
    var EVENT_RENDER_ERROR = 6;
    var EVENT_RENDERING_START = 7;
    var EVENT_STREAM_COMPLETED = 8;
    var EVENT_LOADED_METADATA = 9;
    var EVENT_BUFFERING_START = 11;
    var EVENT_BUFFERING_COMPLETE = 12;
    var EVENT_BUFFERING_PROGRESS = 13;
    var EVENT_CURRENT_PLAYTIME = 14;

    var widgetApi = null;
    var tvKeys = null;
    var player = null;
    var windowPlugin = null;
    var nnaviPlugin = null;
    var tvmwPlugin = null;
    var audioPlugin = null;
    var appCommonPlugin = null;
    var playerOpened = false;
    var loaded = false;
    var playing = false;
    var paused = false;
    var retryCount = 0;
    var cycleId = 0;
    var activeRequest = null;
    var retryTimer = null;
    var watchdogTimer = null;
    var toastTimer = null;
    var screenSaverDisabled = false;

    var statusScreen;
    var statusTitle;
    var statusDetail;
    var statusHelp;
    var spinner;
    var toast;

    function getElement(id) {
        return document.getElementById(id);
    }

    function openSef(elementId, name) {
        var object = getElement(elementId);
        var result;

        if (!object || typeof object.Open !== "function") {
            return null;
        }

        try {
            if (typeof object.Close === "function") {
                object.Close();
            }
        } catch (ignoreCloseError) {
            // The object may not have been open yet.
        }

        try {
            result = object.Open(name, "1.000", name);
            return result === 1 ? object : null;
        } catch (openError) {
            return null;
        }
    }

    function initializeSamsungApis() {
        try {
            if (root.Common && root.Common.API && root.Common.API.Widget) {
                widgetApi = new root.Common.API.Widget();
            }
            if (root.Common && root.Common.API && root.Common.API.TVKeyValue) {
                tvKeys = new root.Common.API.TVKeyValue();
            }
        } catch (commonApiError) {
            widgetApi = null;
            tvKeys = null;
        }

        windowPlugin = openSef("sefWindow", "Window");
        player = openSef("sefPlayer", "Player");
        nnaviPlugin = openSef("sefNNavi", "NNavi");
        tvmwPlugin = openSef("sefTVMW", "TVMW");
        audioPlugin = openSef("sefAudio", "Audio");
        appCommonPlugin = openSef("sefAppCommon", "AppCommon");

        if (!player) {
            return false;
        }

        playerOpened = true;
        player.OnEvent = onPlayerEvent;

        if (windowPlugin) {
            try {
                if (windowPlugin.Execute("GetSource") !== MEDIA_SOURCE) {
                    windowPlugin.Execute("SetSource", MEDIA_SOURCE);
                }
            } catch (sourceError) {
                // Playback can still succeed without explicitly switching the source.
            }
        }
        return true;
    }

    function cacheElements() {
        statusScreen = getElement("statusScreen");
        statusTitle = getElement("statusTitle");
        statusDetail = getElement("statusDetail");
        statusHelp = getElement("statusHelp");
        spinner = getElement("spinner");
        toast = getElement("toast");
    }

    function showStatus(title, detail, isError) {
        statusScreen.className = isError ? "status-screen error" : "status-screen";
        statusScreen.style.display = "block";
        statusTitle.innerHTML = title;
        statusDetail.innerHTML = detail || "";
        statusHelp.innerHTML = "ОК — повторить · RETURN — выйти";
        spinner.style.display = "block";
    }

    function hideStatus() {
        statusScreen.style.display = "none";
    }

    function showToast(message) {
        if (toastTimer) {
            clearTimeout(toastTimer);
        }
        toast.innerHTML = message;
        toast.style.display = "block";
        toastTimer = setTimeout(function () {
            toast.style.display = "none";
            toastTimer = null;
        }, 2200);
    }

    function clearTimers() {
        if (retryTimer) {
            clearTimeout(retryTimer);
            retryTimer = null;
        }
        if (watchdogTimer) {
            clearTimeout(watchdogTimer);
            watchdogTimer = null;
        }
    }

    function abortRequest() {
        cycleId += 1;
        if (activeRequest) {
            try {
                activeRequest.abort();
            } catch (abortError) {
                // Ignore an already completed request.
            }
            activeRequest = null;
        }
    }

    function fetchText(url, timeoutMs, callback) {
        var xhr = new XMLHttpRequest();
        var finished = false;
        var timeout;

        activeRequest = xhr;

        function finish(error, text) {
            if (finished) {
                return;
            }
            finished = true;
            clearTimeout(timeout);
            if (activeRequest === xhr) {
                activeRequest = null;
            }
            callback(error, text || "");
        }

        xhr.onreadystatechange = function () {
            var status;
            if (xhr.readyState !== 4) {
                return;
            }
            status = xhr.status;
            if ((status >= 200 && status < 300) || (status === 0 && xhr.responseText)) {
                finish(null, xhr.responseText);
            } else {
                finish("HTTP " + status, "");
            }
        };

        xhr.onerror = function () {
            finish("NETWORK", "");
        };

        timeout = setTimeout(function () {
            try {
                xhr.abort();
            } catch (timeoutAbortError) {
                // Ignore abort errors.
            }
            finish("TIMEOUT", "");
        }, timeoutMs);

        try {
            xhr.open("GET", url, true);
            xhr.send(null);
        } catch (requestError) {
            finish("REQUEST", "");
        }
    }

    function resolveAndPlay() {
        var thisCycle;
        var resolverUrl;

        if (!loaded || !playerOpened) {
            return;
        }

        clearTimers();
        abortRequest();
        stopPlayback();
        thisCycle = cycleId;

        resolverUrl = root.StreamTools.LOCAL_RESOLVER_URL || "";
        if (resolverUrl.indexOf("__FIRST_TULA_") !== 0) {
            showStatus("Получаю прямую трансляцию…", "Подключение через локальный сервер", false);
            fetchText(resolverUrl + "?time=" + new Date().getTime(), 35000, function (resolverError, resolvedUrl) {
                var streamUrl;
                if (thisCycle !== cycleId || !loaded) {
                    return;
                }
                streamUrl = String(resolvedUrl || "").replace(/^\s+|\s+$/g, "");
                if (resolverError || !/^https?:\/\//i.test(streamUrl)) {
                    scheduleRetry("Компьютер не смог получить адрес трансляции");
                    return;
                }
                playHls(root.StreamTools.toLegacyTransport(streamUrl));
            });
            return;
        }

        showStatus("Получаю прямую трансляцию…", "Проверяю официальный источник", false);

        fetchText(root.StreamTools.LIVE_PAGE_URL, 18000, function (liveError, liveHtml) {
            var embedUrl;
            if (thisCycle !== cycleId || !loaded) {
                return;
            }

            embedUrl = liveError ? null : root.StreamTools.findOkEmbedUrl(liveHtml);
            resolveFromEmbed(embedUrl || root.StreamTools.FALLBACK_EMBED_URL, thisCycle);
        });
    }

    function resolveFromEmbed(embedUrl, thisCycle) {
        showStatus("Подключаюсь к эфиру…", "Получаю временный адрес видеопотока", false);

        fetchText(embedUrl, 20000, function (embedError, playerHtml) {
            var hlsUrl;
            var legacyUrl;

            if (thisCycle !== cycleId || !loaded) {
                return;
            }
            if (embedError) {
                scheduleRetry("Телевизор не смог открыть страницу трансляции");
                return;
            }

            hlsUrl = root.StreamTools.findHlsUrl(playerHtml);
            if (!hlsUrl) {
                scheduleRetry("Адрес видеопотока не найден");
                return;
            }

            legacyUrl = root.StreamTools.toLegacyTransport(hlsUrl);
            showStatus("Выбираю качество 720p…", "Оптимизация потока для Samsung F‑серии", false);

            fetchText(legacyUrl, 14000, function (masterError, masterText) {
                var selectedUrl = legacyUrl;
                if (thisCycle !== cycleId || !loaded) {
                    return;
                }
                if (!masterError) {
                    selectedUrl = root.StreamTools.selectBest720p(masterText, legacyUrl);
                }
                playHls(selectedUrl);
            });
        });
    }

    function setDisplayArea() {
        if (!playerOpened) {
            return;
        }
        try {
            player.Execute("SetDisplayArea", 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_HEIGHT);
        } catch (displayError) {
            try {
                player.Execute("SetDisplayArea", 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
            } catch (fallbackDisplayError) {
                // A playback error callback or watchdog will handle the failure.
            }
        }
    }

    function playHls(url) {
        var initResult;
        var startResult;

        stopPlayback();
        playing = false;
        paused = false;
        showStatus("Буферизация…", "Запускаю прямой эфир", false);

        try {
            initResult = player.Execute("InitPlayer", url + PLAYER_COMPONENT);
            setDisplayArea();
            startResult = player.Execute("StartPlayback", 0);
            if ((Number(initResult) + Number(startResult)) <= 0) {
                scheduleRetry("Плеер телевизора отклонил видеопоток");
                return;
            }
        } catch (playError) {
            scheduleRetry("Не удалось запустить встроенный плеер");
            return;
        }

        watchdogTimer = setTimeout(function () {
            if (!playing && loaded) {
                scheduleRetry("Видео не начало воспроизводиться вовремя");
            }
        }, 32000);
    }

    function markPlaying() {
        if (playing) {
            return;
        }
        playing = true;
        paused = false;
        retryCount = 0;
        if (watchdogTimer) {
            clearTimeout(watchdogTimer);
            watchdogTimer = null;
        }
        setScreenSaverEnabled(false);
        hideStatus();
    }

    function onPlayerEvent(eventType, data1) {
        var type = Number(eventType);

        if (!loaded) {
            return;
        }

        switch (type) {
        case EVENT_LOADED_METADATA:
            setDisplayArea();
            break;
        case EVENT_BUFFERING_START:
            showStatus("Буферизация…", "Соединение с прямым эфиром", false);
            break;
        case EVENT_BUFFERING_PROGRESS:
            if (!playing) {
                statusDetail.innerHTML = "Загружено: " + String(data1 || 0) + "%";
            }
            break;
        case EVENT_BUFFERING_COMPLETE:
            if (playing && !paused) {
                hideStatus();
            }
            break;
        case EVENT_RENDERING_START:
        case EVENT_CURRENT_PLAYTIME:
            markPlaying();
            break;
        case EVENT_STREAM_COMPLETED:
            scheduleRetry("Прямой эфир был завершён источником");
            break;
        case EVENT_CONNECTION_FAILED:
        case EVENT_AUTHENTICATION_FAILED:
        case EVENT_STREAM_NOT_FOUND:
        case EVENT_NETWORK_DISCONNECTED:
        case EVENT_NETWORK_SLOW:
        case EVENT_RENDER_ERROR:
            scheduleRetry("Ошибка воспроизведения (код " + type + ")");
            break;
        default:
            break;
        }
    }

    function stopPlayback() {
        if (!playerOpened) {
            return;
        }
        try {
            player.Execute("Stop");
        } catch (stopError) {
            // It is valid to stop an idle player before a retry.
        }
        playing = false;
        paused = false;
    }

    function scheduleRetry(reason) {
        var delays = [5000, 10000, 20000, 30000, 60000];
        var delay;

        if (!loaded) {
            return;
        }

        clearTimers();
        abortRequest();
        stopPlayback();
        setScreenSaverEnabled(true);
        delay = delays[Math.min(retryCount, delays.length - 1)];
        retryCount += 1;

        showStatus(
            "Эфир временно недоступен",
            reason + ". Автоповтор через " + Math.round(delay / 1000) + " сек.",
            true
        );

        retryTimer = setTimeout(function () {
            retryTimer = null;
            resolveAndPlay();
        }, delay);
    }

    function retryNow() {
        retryCount = 0;
        resolveAndPlay();
    }

    function togglePause() {
        var result;

        if (!playing || !playerOpened) {
            retryNow();
            return;
        }

        try {
            if (paused) {
                result = player.Execute("Resume");
                if (Number(result) > 0) {
                    paused = false;
                    hideStatus();
                    showToast("Воспроизведение");
                }
            } else {
                result = player.Execute("Pause");
                if (Number(result) > 0) {
                    paused = true;
                    showToast("Пауза");
                }
            }
        } catch (pauseError) {
            scheduleRetry("Плеер не ответил на команду");
        }
    }

    function setScreenSaverEnabled(enabled) {
        var profile;
        var seconds;
        var durations = [300, 600, 1200, 1800, 2400, 3600, 7200, 14400, 28800, 36000, -1];

        if (!nnaviPlugin || !tvmwPlugin) {
            return;
        }

        try {
            if (!enabled) {
                nnaviPlugin.Execute("SendEventToDevice", 4, 0);
                screenSaverDisabled = true;
                return;
            }

            if (!screenSaverDisabled) {
                return;
            }
            profile = parseInt(tvmwPlugin.Execute("GetProfile", 13), 10);
            seconds = durations[profile];
            if (!(seconds > 0)) {
                seconds = 7200;
            }
            nnaviPlugin.Execute("SendEventToDevice", 3, seconds);
            screenSaverDisabled = false;
        } catch (screenSaverError) {
            // Screen saver control is optional and differs between firmware builds.
        }
    }

    function keyValue(name, fallback) {
        if (tvKeys && typeof tvKeys[name] !== "undefined") {
            return tvKeys[name];
        }
        return fallback;
    }

    function getAudioControl() {
        if (root.deviceapis && root.deviceapis.audiocontrol) {
            return root.deviceapis.audiocontrol;
        }
        if (root.webapis && root.webapis.audiocontrol) {
            return root.webapis.audiocontrol;
        }
        return null;
    }

    function showCurrentVolume(control) {
        var volume = null;

        if (!toast) {
            return;
        }
        try {
            if (control && typeof control.getVolume === "function") {
                volume = control.getVolume();
            } else if (audioPlugin) {
                volume = audioPlugin.Execute("GetVolume");
            }
        } catch (volumeError) {
            volume = null;
        }
        if (Number(volume) >= 0) {
            showToast("Громкость: " + String(volume));
        }
    }

    function adjustVolume(direction) {
        var control = getAudioControl();
        var result;

        if (control) {
            try {
                if (direction > 0 && typeof control.setVolumeUp === "function") {
                    control.setVolumeUp();
                    showCurrentVolume(control);
                    return true;
                }
                if (direction < 0 && typeof control.setVolumeDown === "function") {
                    control.setVolumeDown();
                    showCurrentVolume(control);
                    return true;
                }
            } catch (audioControlError) {
                // Fall back to the Audio SEF plugin used on older 2013 firmware.
            }
        }

        if (audioPlugin) {
            try {
                result = audioPlugin.Execute(
                    "SetRelativeVolume",
                    direction > 0 ? "1" : "-1"
                );
                if (Number(result) >= 0) {
                    showCurrentVolume(null);
                    return true;
                }
            } catch (audioPluginError) {
                // Fall back to forwarding the original key to TVViewer.
            }
        }

        if (appCommonPlugin) {
            try {
                appCommonPlugin.Execute("SendKeyToTVViewer", direction > 0 ? 7 : 11);
                return true;
            } catch (appCommonError) {
                // Let the television process the unhandled key normally.
            }
        }
        return false;
    }

    function toggleMute() {
        var control = getAudioControl();
        var muted;
        var result;

        if (control && typeof control.getMute === "function" &&
                typeof control.setMute === "function") {
            try {
                muted = Boolean(control.getMute());
                control.setMute(!muted);
                if (toast) {
                    showToast(muted ? "Звук включён" : "Звук выключен");
                }
                return true;
            } catch (muteControlError) {
                // Fall back to the Audio SEF plugin.
            }
        }

        if (audioPlugin) {
            try {
                muted = Number(audioPlugin.Execute("GetUserMute")) > 0;
                result = audioPlugin.Execute("SetUserMute", muted ? 0 : 1);
                if (Number(result) >= 0) {
                    if (toast) {
                        showToast(muted ? "Звук включён" : "Звук выключен");
                    }
                    return true;
                }
            } catch (mutePluginError) {
                // Fall back to forwarding the original key to TVViewer.
            }
        }

        if (appCommonPlugin) {
            try {
                appCommonPlugin.Execute("SendKeyToTVViewer", 27);
                return true;
            } catch (appCommonError) {
                // Let the television process the unhandled key normally.
            }
        }
        return false;
    }

    function isVolumeUpKey(code) {
        return code === keyValue("KEY_VOL_UP", 447) ||
            code === keyValue("KEY_PANEL_VOL_UP", 203) || code === 7;
    }

    function isVolumeDownKey(code) {
        return code === keyValue("KEY_VOL_DOWN", 448) ||
            code === keyValue("KEY_PANEL_VOL_DOWN", 204) || code === 11;
    }

    function isMuteKey(code) {
        return code === keyValue("KEY_MUTE", 449) || code === 27;
    }

    function onKeyDown(eventObject) {
        var keyEvent = eventObject || root.event;
        var code = keyEvent ? keyEvent.keyCode : 0;

        if (isVolumeUpKey(code)) {
            return adjustVolume(1) ? false : true;
        }
        if (isVolumeDownKey(code)) {
            return adjustVolume(-1) ? false : true;
        }
        if (isMuteKey(code)) {
            return toggleMute() ? false : true;
        }

        if (code === keyValue("KEY_RETURN", 88)) {
            closeApplication(false);
            return false;
        }
        if (code === keyValue("KEY_EXIT", 45)) {
            closeApplication(true);
            return false;
        }
        if (code === keyValue("KEY_ENTER", 29443) || code === 13 ||
                code === keyValue("KEY_RED", 108)) {
            retryNow();
            return false;
        }
        if (code === keyValue("KEY_PLAY", 71)) {
            if (paused) {
                togglePause();
            }
            return false;
        }
        if (code === keyValue("KEY_PAUSE", 74)) {
            if (!paused) {
                togglePause();
            }
            return false;
        }
        if (code === keyValue("KEY_STOP", 70)) {
            retryNow();
            return false;
        }
        return true;
    }

    function closeSef(object) {
        if (!object || typeof object.Close !== "function") {
            return;
        }
        try {
            object.Close();
        } catch (closeError) {
            // Application shutdown must continue.
        }
    }

    function shutdown() {
        if (!loaded) {
            return;
        }
        loaded = false;
        clearTimers();
        abortRequest();
        stopPlayback();
        setScreenSaverEnabled(true);
        closeSef(player);
        closeSef(windowPlugin);
        closeSef(nnaviPlugin);
        closeSef(tvmwPlugin);
        closeSef(audioPlugin);
        closeSef(appCommonPlugin);
        playerOpened = false;
    }

    function closeApplication(exitCompletely) {
        shutdown();
        try {
            if (widgetApi) {
                if (exitCompletely && typeof widgetApi.sendExitEvent === "function") {
                    widgetApi.sendExitEvent();
                } else if (typeof widgetApi.sendReturnEvent === "function") {
                    widgetApi.sendReturnEvent();
                }
                return;
            }
        } catch (widgetCloseError) {
            // Fall through to window.close().
        }
        root.close();
    }

    function onLoad() {
        var keyCatcher;

        if (loaded) {
            return;
        }
        loaded = true;
        cacheElements();
        showStatus("Запуск прямого эфира…", "Инициализация плеера телевизора", false);

        document.onkeydown = onKeyDown;
        keyCatcher = getElement("keyCatcher");
        if (keyCatcher && typeof keyCatcher.focus === "function") {
            keyCatcher.focus();
        }

        if (!initializeSamsungApis()) {
            showStatus(
                "Не найден Samsung Player",
                "Этот пакет предназначен для телевизоров Samsung Legacy/Orsay 2013 года",
                true
            );
            return;
        }

        try {
            if (widgetApi && typeof widgetApi.sendReadyEvent === "function") {
                widgetApi.sendReadyEvent();
            }
        } catch (readyError) {
            // The player can still be started on some firmware versions.
        }

        setTimeout(resolveAndPlay, 100);
    }

    function onUnload() {
        shutdown();
    }

    root.FirstTulaApp = {
        onLoad: onLoad,
        onUnload: onUnload,
        onKeyDown: onKeyDown
    };
}(this));
