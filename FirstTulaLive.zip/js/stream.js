(function (root) {
    "use strict";

    var LIVE_PAGE_URL = "https://1tulatv.ru/live";
    var FALLBACK_EMBED_URL = "https://ok.ru/videoembed/977507065564?autoplay=1";
    var LOCAL_RESOLVER_URL = "__FIRST_TULA_RESOLVER_URL__";

    function decodeEntities(value) {
        return String(value || "")
            .replace(/&quot;|&#34;|&#x22;/gi, "\"")
            .replace(/&amp;|&#38;|&#x26;/gi, "&")
            .replace(/&#47;|&#x2f;/gi, "/")
            .replace(/&lt;/gi, "<")
            .replace(/&gt;/gi, ">");
    }

    function normalizeEscapedPayload(value) {
        return decodeEntities(value)
            .replace(/\\\"/g, "\"")
            .replace(/\\\//g, "/")
            .replace(/\\u0026/gi, "&")
            .replace(/\\u003d/gi, "=")
            .replace(/\\u003f/gi, "?");
    }

    function cleanUrl(value) {
        return normalizeEscapedPayload(value)
            .replace(/^\s+|\s+$/g, "")
            .replace(/[\"'<>]+$/g, "");
    }

    function withAutoplay(url) {
        if (/([?&])autoplay=/i.test(url)) {
            return url;
        }
        return url + (url.indexOf("?") >= 0 ? "&" : "?") + "autoplay=1";
    }

    function findOkEmbedUrl(pageHtml) {
        var match;
        var url;

        if (!pageHtml) {
            return null;
        }

        match = /<iframe[^>]+src=[\"']((?:https?:)?\/\/ok\.ru\/videoembed\/[^\"'<>\s]+)/i.exec(pageHtml);
        if (!match) {
            return null;
        }

        url = cleanUrl(match[1]);
        if (url.indexOf("//") === 0) {
            url = "https:" + url;
        }
        return withAutoplay(url);
    }

    function findHlsUrl(playerHtml) {
        var normalized;
        var match;

        if (!playerHtml) {
            return null;
        }

        normalized = normalizeEscapedPayload(playerHtml);
        match = /[\"]hlsMasterPlaylistUrl[\"]\s*:\s*[\"](https?:\/\/[^\"]+)[\"]/i.exec(normalized);
        if (match) {
            return cleanUrl(match[1]);
        }

        match = /(https?:\/\/[^\s\"'<>]+\.m3u8(?:\?[^\s\"'<>]*)?)/i.exec(normalized);
        return match ? cleanUrl(match[1]) : null;
    }

    function toLegacyTransport(url) {
        if (/^https:\/\/[^\/]*\.okcdn\.ru\//i.test(url)) {
            return "http://" + url.substring(8);
        }
        return url;
    }

    function makeAbsolute(baseUrl, reference) {
        var schemeMatch;
        var slash;

        if (/^https?:\/\//i.test(reference)) {
            return reference;
        }

        if (reference.indexOf("//") === 0) {
            schemeMatch = /^(https?:)/i.exec(baseUrl);
            return (schemeMatch ? schemeMatch[1] : "http:") + reference;
        }

        slash = baseUrl.lastIndexOf("/");
        if (slash < 0) {
            return reference;
        }
        return baseUrl.substring(0, slash + 1) + reference;
    }

    function selectBest720p(masterText, masterUrl) {
        var lines;
        var candidates = [];
        var i;
        var info;
        var uri;
        var resolution;
        var bandwidth;
        var candidate;
        var best = null;
        var fallback = null;

        if (!masterText || masterText.indexOf("#EXTM3U") < 0) {
            return masterUrl;
        }

        lines = masterText.replace(/\r/g, "").split("\n");
        for (i = 0; i < lines.length; i += 1) {
            info = lines[i].replace(/^\s+|\s+$/g, "");
            if (info.indexOf("#EXT-X-STREAM-INF:") !== 0) {
                continue;
            }

            uri = "";
            while (i + 1 < lines.length && !uri) {
                i += 1;
                uri = lines[i].replace(/^\s+|\s+$/g, "");
                if (uri.indexOf("#") === 0) {
                    uri = "";
                }
            }
            if (!uri) {
                continue;
            }

            resolution = /RESOLUTION=(\d+)x(\d+)/i.exec(info);
            bandwidth = /BANDWIDTH=(\d+)/i.exec(info);
            candidate = {
                url: makeAbsolute(masterUrl, uri),
                width: resolution ? parseInt(resolution[1], 10) : 0,
                height: resolution ? parseInt(resolution[2], 10) : 0,
                bandwidth: bandwidth ? parseInt(bandwidth[1], 10) : 0
            };
            candidates.push(candidate);
        }

        for (i = 0; i < candidates.length; i += 1) {
            candidate = candidates[i];
            if (!fallback || candidate.bandwidth < fallback.bandwidth) {
                fallback = candidate;
            }
            if (candidate.height > 0 && candidate.height <= 720) {
                if (!best || candidate.height > best.height ||
                        (candidate.height === best.height && candidate.bandwidth > best.bandwidth)) {
                    best = candidate;
                }
            }
        }

        return toLegacyTransport((best || fallback) ? (best || fallback).url : masterUrl);
    }

    var api = {
        LIVE_PAGE_URL: LIVE_PAGE_URL,
        FALLBACK_EMBED_URL: FALLBACK_EMBED_URL,
        LOCAL_RESOLVER_URL: LOCAL_RESOLVER_URL,
        findOkEmbedUrl: findOkEmbedUrl,
        findHlsUrl: findHlsUrl,
        selectBest720p: selectBest720p,
        toLegacyTransport: toLegacyTransport,
        normalizeEscapedPayload: normalizeEscapedPayload
    };

    root.StreamTools = api;
    if (typeof module !== "undefined" && module.exports) {
        module.exports = api;
    }
}(this));
